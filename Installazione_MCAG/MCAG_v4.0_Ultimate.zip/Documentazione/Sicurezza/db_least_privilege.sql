-- Documentazione: Politiche di Accesso Database (Least Privilege)
-- Questo file documenta i permessi minimi necessari per l'utente applicativo.

-- 1. Utente Applicativo (es. 'MCAG_app')
-- Deve poter leggere/scrivere dati ma non alterare lo schema in produzione.
GRANT SELECT, INSERT, UPDATE, DELETE ON MCAG_db.* TO 'MCAG_app'@'%';

-- 2. Utente Backup (es. 'MCAG_backup')
-- Deve poter fare LOCK TABLES e SELECT per i dump.
GRANT SELECT, LOCK TABLES, SHOW VIEW, EVENT, TRIGGER ON MCAG_db.* TO 'MCAG_backup'@'localhost';

-- 3. Utente Migrazioni/Admin (es. 'MCAG_admin')
-- Solo questo utente deve avere DROP/ALTER/CREATE.
-- Usato solo durante i deploy o manutenzione.
GRANT ALL PRIVILEGES ON MCAG_db.* TO 'MCAG_admin'@'localhost';

-- Note di Sicurezza:
-- - Revocare FILE privilege se non strettamente necessario.
-- - Assicurare che 'MCAG_app' NON abbia GRANT OPTION.
-- - Monitorare accessi via Audit Logs.
