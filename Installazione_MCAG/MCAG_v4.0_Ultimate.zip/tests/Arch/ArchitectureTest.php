<?php

arch('controllers')
    /** @phpstan-ignore-next-line */
    ->expect('MCAGMilitare\Controller')
    ->not->toUse('MCAGMilitare\InfrastrutturaIT\Persistence\DatabaseConnection')
    ->ignoring([
        // NEW: Auth Controllers (direct user table access for security)
        'MCAGMilitare\Controller\Auth\LoginFlowController',
        'MCAGMilitare\Controller\Auth\TwoFactorController',
        'MCAGMilitare\Controller\Auth\LogoutController',
        'MCAGMilitare\Controller\SettingsController',
        // NEW: Granular DevTools Controllers (use DatabaseConnection for admin operations)
        'MCAGMilitare\Controller\DevTools\DevToolsDashboardController',
        'MCAGMilitare\Controller\DevTools\DevToolsFileSystemController',
        'MCAGMilitare\Controller\DevTools\DevToolsDatabaseController',
        'MCAGMilitare\Controller\DevTools\DevToolsSecurityController',
        'MCAGMilitare\Controller\DevTools\DevToolsScriptController',
        'MCAGMilitare\Controller\DevTools\DevToolsSystemController',
        'MCAGMilitare\Controller\DevTools\DevToolsAuditController',
    ]);
// Example exception if strictly needed, but ideally should be clean.

arch('debug')
    /** @phpstan-ignore-next-line */
    ->expect(['dd', 'dump', 'die', 'var_dump'])
    ->not->toBeUsed();

arch('models')
    /** @phpstan-ignore-next-line */
    ->expect('MCAGMilitare\SecurityLayer')
    ->not->toUse('MCAGMilitare\Controller');
