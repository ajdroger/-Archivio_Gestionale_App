<?php

use Psr\Container\ContainerInterface;

return [
    \MCAGMilitare\Controller\Auth\LoginFlowController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\Auth\LoginFlowController($c->get(Mustache_Engine::class));
    },
    \MCAGMilitare\Controller\Auth\TwoFactorController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\Auth\TwoFactorController($c->get(Mustache_Engine::class));
    },
    \MCAGMilitare\Controller\Auth\LogoutController::class => function () {
        return new \MCAGMilitare\Controller\Auth\LogoutController();
    },
];
