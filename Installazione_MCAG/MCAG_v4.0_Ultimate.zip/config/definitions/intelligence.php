<?php

use Psr\Container\ContainerInterface;

return [
    \MCAGMilitare\Controller\Intelligence\StatsDashboardController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\Intelligence\StatsDashboardController(
            $c->get(Mustache_Engine::class),
            $c->get(\MCAGMilitare\GestioneSoci\SocioRepository::class),
            $c->get(\MCAGMilitare\Debug\ResilienceMonitor::class),
            $c->get(\MCAGMilitare\Service\HealthCheckService::class)
        );
    },
    \MCAGMilitare\Controller\Intelligence\ReportExportController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\Intelligence\ReportExportController(
            $c->get(Mustache_Engine::class),
            $c->get(\MCAGMilitare\GestioneSoci\SocioRepository::class)
        );
    },
];
