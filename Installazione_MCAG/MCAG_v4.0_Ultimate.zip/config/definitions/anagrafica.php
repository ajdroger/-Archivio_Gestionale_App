<?php

use Psr\Container\ContainerInterface;
use MCAGMilitare\InfrastrutturaIT\Persistence\PDOSocioRepository;

return [
    \MCAGMilitare\Controller\Anagrafica\Soci\ListController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\Anagrafica\Soci\ListController(
            $c->get(Mustache_Engine::class),
            $c->get(PDOSocioRepository::class)
        );
    },
    \MCAGMilitare\Controller\Anagrafica\Soci\DetailController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\Anagrafica\Soci\DetailController(
            $c->get(Mustache_Engine::class),
            $c->get(PDOSocioRepository::class),
            $c->get('audit_logger')
        );
    },
    \MCAGMilitare\Controller\Anagrafica\Soci\PersistenceController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\Anagrafica\Soci\PersistenceController(
            $c->get(Mustache_Engine::class),
            $c->get(PDOSocioRepository::class),
            $c->get('audit_logger'),
            $c->get(\MCAGMilitare\Service\ValidationService::class),
            $c->get(\MCAGMilitare\Service\RegistrationService::class)
        );
    },
    \MCAGMilitare\Controller\Anagrafica\Soci\ActionController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\Anagrafica\Soci\ActionController($c->get('audit_logger'));
    },
    \MCAGMilitare\Controller\Anagrafica\Documenti\StorageController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\Anagrafica\Documenti\StorageController(
            $c->get(PDOSocioRepository::class),
            $c->get('audit_logger'),
            $c->get(\MCAGMilitare\Service\ValidationService::class)
        );
    },
    \MCAGMilitare\Controller\Anagrafica\Servizi\SocioExportController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\Anagrafica\Servizi\SocioExportController($c->get(PDOSocioRepository::class));
    },
];
