<?php

use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;

return [
    // ===== NEW SERVICES - Q1 & Q2 =====

    \MCAGMilitare\Service\RedisService::class => function () {
        return new \MCAGMilitare\Service\RedisService();
    },

    \MCAGMilitare\Service\CacheService::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Service\CacheService(
            $c->get(\MCAGMilitare\Service\RedisService::class)
        );
    },

    \MCAGMilitare\Service\QueueService::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Service\QueueService(
            $c->get(PDO::class)
        );
    },

    \MCAGMilitare\Service\BackupVerificationService::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Service\BackupVerificationService(
            $c->get(PDO::class),
            __DIR__ . '/../../storage/backups'
        );
    },

    \MCAGMilitare\Service\HealthCheckService::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Service\HealthCheckService(
            $c->get(PDO::class),
            $c->get(\MCAGMilitare\Service\RedisService::class),
            $c->get(\MCAGMilitare\Service\QueueService::class),
            __DIR__ . '/../../storage'
        );
    },

    \MCAGMilitare\Service\JsonLogFormatter::class => function () {
        return new \MCAGMilitare\Service\JsonLogFormatter('MCAGMilitare');
    },

    // ===== EXISTING SERVICES =====
    \MCAGMilitare\Service\ValidationService::class => function () {
        return new \MCAGMilitare\Service\ValidationService();
    },

    \MCAGMilitare\Service\BackupService::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Service\BackupService(
            __DIR__ . '/../../database.sqlite',
            __DIR__ . '/../../storage/backups',
            $c->get(LoggerInterface::class),
            14
        );
    },

    \MCAGMilitare\Debug\ResilienceMonitor::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Debug\ResilienceMonitor(
            $c->get(PDO::class),
            $c->get(LoggerInterface::class),
            __DIR__ . '/../../storage'
        );
    },

    \MCAGMilitare\Service\EmailServiceInterface::class => function (ContainerInterface $c) {
        $config = [
            'host' => $_ENV['SMTP_HOST'] ?? 'smtp.example.com',
            'username' => $_ENV['SMTP_USER'] ?? 'user@example.com',
            'password' => $_ENV['SMTP_PASS'] ?? 'secret',
            'port' => $_ENV['SMTP_PORT'] ?? 587
        ];
        return new \MCAGMilitare\Service\SmtpEmailService($c->get(LoggerInterface::class), $config);
    },

    \MCAGMilitare\Service\PdfGenerationService::class => function () {
        return new \MCAGMilitare\Service\PdfGenerationService();
    },

    \MCAGMilitare\Service\RegistrationService::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Service\RegistrationService(
            $c->get(\MCAGMilitare\GestioneSoci\SocioRepository::class),
            $c->get(\MCAGMilitare\Service\ValidationService::class),
            $c->get(\MCAGMilitare\Service\PdfGenerationService::class),
            $c->get(\MCAGMilitare\Service\EmailServiceInterface::class),
            $c->get(LoggerInterface::class)
        );
    },
];
