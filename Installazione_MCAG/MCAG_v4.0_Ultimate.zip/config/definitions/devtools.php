<?php

use Psr\Container\ContainerInterface;

return [
    \MCAGMilitare\Controller\SettingsController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\SettingsController($c->get(Mustache_Engine::class));
    },

    \MCAGMilitare\Controller\HomeController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\HomeController(
            $c->get(Mustache_Engine::class),
            $c->get(\MCAGMilitare\GestioneSoci\SocioRepository::class)
        );
    },

    \MCAGMilitare\Controller\DevTools\DevToolsSystemController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\DevTools\DevToolsSystemController(
            $c->get(Mustache_Engine::class),
            $c->get(\MCAGMilitare\Debug\ResilienceMonitor::class),
            $c->get(PDO::class)
        );
    },

    \MCAGMilitare\Controller\DevTools\DevToolsAuditController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\DevTools\DevToolsAuditController(
            $c->get(Mustache_Engine::class),
            $c->get(PDO::class)
        );
    },

    \MCAGMilitare\Controller\DevTools\DevToolsDashboardController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\DevTools\DevToolsDashboardController(
            $c->get(Mustache_Engine::class),
            $c->get(\MCAGMilitare\Controller\DevTools\DevToolsSystemController::class),
            $c->get(\MCAGMilitare\Controller\DevTools\DevToolsAuditController::class)
        );
    },

    \MCAGMilitare\Controller\DevTools\DevToolsFileSystemController::class => function () {
        return new \MCAGMilitare\Controller\DevTools\DevToolsFileSystemController();
    },

    \MCAGMilitare\Controller\DevTools\DevToolsDatabaseController::class => function (ContainerInterface $c) {
        return new \MCAGMilitare\Controller\DevTools\DevToolsDatabaseController(
            $c->get(Mustache_Engine::class)
        );
    },

    \MCAGMilitare\Controller\DevTools\DevToolsSecurityController::class => function () {
        return new \MCAGMilitare\Controller\DevTools\DevToolsSecurityController();
    },

    \MCAGMilitare\Controller\DevTools\DevToolsScriptController::class => function () {
        return new \MCAGMilitare\Controller\DevTools\DevToolsScriptController();
    },
];
