<?php
declare(strict_types=1);

namespace MCAGMilitare\GraphQL;

use GraphQL\Type\Schema as GraphQLSchema;
use MCAGMilitare\GraphQL\Types\QueryType;
use MCAGMilitare\InfrastrutturaIT\Persistence\PDOSocioRepository;

class Schema
{
    public static function build(PDOSocioRepository $repo): GraphQLSchema
    {
        $queryType = new QueryType($repo);

        return new GraphQLSchema([
            'query' => $queryType
        ]);
    }
}
