<?php

namespace MCAGMilitare\Enum;

enum StatoDocumento
{
    case IN_ATTESA;
    case VALIDATO;
    case RESPINTO;
    case ARCHIVIATO;
}
