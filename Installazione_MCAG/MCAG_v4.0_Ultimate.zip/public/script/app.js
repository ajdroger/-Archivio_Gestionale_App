/**
 * MCAG - App Scripts
 */
document.addEventListener('DOMContentLoaded', () => {
    console.log('MCAG IT System Initialized');
});
